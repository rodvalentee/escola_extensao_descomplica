// TurmaController.java
package com.escolinha.escolinha.controller;

import com.escolinha.escolinha.model.Turma;
import com.escolinha.escolinha.model.AlunoTurma;
import com.escolinha.escolinha.service.TurmaService;
import com.escolinha.escolinha.service.AlunoTurmaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/turmas")
@RequiredArgsConstructor
public class TurmaController {
    private final TurmaService turmaService;
    private final AlunoTurmaService atService;



    @PostMapping
    public ResponseEntity<Turma> criar(@RequestBody Turma t) {
        // 1) Veja se o método é invocado:
        System.out.println(">>> [Controller] POST /api/turmas chamado");
        // 2) Veja o conteúdo de 't' e do seu campo 'professor':
        System.out.println(">>> [Controller] Turma recebido = " + t);
        System.out.println(">>> [Controller] professor recebido = " + t.getProfessor());
        Turma salvo = turmaService.criar(t);
        System.out.println(">>> [Controller] Turma salva no BD com ID = " + salvo.getId());
        return ResponseEntity.ok(salvo);
    }


    @GetMapping
    public ResponseEntity<List<Turma>> listar() {
        return ResponseEntity.ok(turmaService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turma> detalhar(@PathVariable Long id) {
        return ResponseEntity.ok(turmaService.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Turma> atualizar(@PathVariable Long id,
                                           @RequestBody Turma dados) {
        return ResponseEntity.ok(turmaService.atualizar(id, dados));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        turmaService.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/alunos")
    public ResponseEntity<List<AlunoTurma>> listarAlunos(@PathVariable Long id) {
        return ResponseEntity.ok(atService.listarPorTurma(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Turma>> buscarPorNome(@RequestParam String nome) {
        return ResponseEntity.ok(turmaService.buscarPorNome(nome));
    }
}
