package com.escolinha.escolinha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscolinhaApplication {

    public static void main(String[] args) {
        SpringApplication.run(EscolinhaApplication.class, args);
    }

}
