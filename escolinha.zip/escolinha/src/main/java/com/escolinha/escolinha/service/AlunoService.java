// AlunoService.java
package com.escolinha.escolinha.service;

import com.escolinha.escolinha.model.Aluno;
import com.escolinha.escolinha.repository.AlunoRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AlunoService {
    private final AlunoRepository repo;

    public Aluno criar(Aluno aluno) {
        return repo.save(aluno);
    }

    public Aluno atualizar(Long id, Aluno dados) {
        Aluno a = buscarPorId(id);
        a.setNome(dados.getNome());
        a.setEmail(dados.getEmail());
        return repo.save(a);
    }

    public void excluir(Long id) {
        repo.deleteById(id);
    }

    public Aluno buscarPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Aluno não encontrado: " + id));
    }

    public List<Aluno> listarTodos() {
        return repo.findAll();
    }

    public List<Aluno> buscarPorNome(String nome) {
        return repo.findByNomeContainingIgnoreCase(nome);
    }
}
