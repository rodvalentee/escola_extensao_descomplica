// AlunoController.java
package com.escolinha.escolinha.controller;

import com.escolinha.escolinha.model.Aluno;
import com.escolinha.escolinha.model.AlunoTurma;
import com.escolinha.escolinha.service.AlunoService;
import com.escolinha.escolinha.service.AlunoTurmaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/alunos")
@RequiredArgsConstructor
public class AlunoController {
    private final AlunoService alunoService;
    private final AlunoTurmaService atService;

    @PostMapping
    public ResponseEntity<Aluno> criar(@RequestBody Aluno a) {
        return ResponseEntity.ok(alunoService.criar(a));
    }

    @GetMapping
    public ResponseEntity<List<Aluno>> listar() {
        return ResponseEntity.ok(alunoService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Aluno> detalhar(@PathVariable Long id) {
        return ResponseEntity.ok(alunoService.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Aluno> atualizar(@PathVariable Long id,
                                           @RequestBody Aluno dados) {
        return ResponseEntity.ok(alunoService.atualizar(id, dados));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        alunoService.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/turmas")
    public ResponseEntity<List<AlunoTurma>> listarTurmas(@PathVariable Long id) {
        return ResponseEntity.ok(atService.listarPorAluno(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Aluno>> buscarPorNome(@RequestParam String nome) {
        return ResponseEntity.ok(alunoService.buscarPorNome(nome));
    }
}
