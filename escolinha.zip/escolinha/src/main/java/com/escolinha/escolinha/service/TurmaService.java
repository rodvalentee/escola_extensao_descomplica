// TurmaService.java
package com.escolinha.escolinha.service;

import com.escolinha.escolinha.model.Turma;
import com.escolinha.escolinha.repository.TurmaRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TurmaService {
    private final TurmaRepository repo;

    public Turma criar(Turma turma) {
        return repo.save(turma);
    }

    public Turma atualizar(Long id, Turma dados) {
        Turma t = buscarPorId(id);
        t.setNome(dados.getNome());
        t.setProfessor(dados.getProfessor());
        return repo.save(t);
    }

    public void excluir(Long id) {
        repo.deleteById(id);
    }

    public Turma buscarPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Turma não encontrada: " + id));
    }

    public List<Turma> listarTodos() {
        return repo.findAll();
    }

    public List<Turma> buscarPorNome(String nome) {
        return repo.findByNomeContainingIgnoreCase(nome);
    }
}
