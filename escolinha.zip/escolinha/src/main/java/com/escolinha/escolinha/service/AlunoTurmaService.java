// AlunoTurmaService.java
package com.escolinha.escolinha.service;

import com.escolinha.escolinha.model.AlunoTurma;
import com.escolinha.escolinha.repository.AlunoTurmaRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AlunoTurmaService {
    private final AlunoTurmaRepository repo;

    public AlunoTurma matricular(AlunoTurma at) {
        return repo.save(at);
    }

    public void desmatricular(Long id) {
        repo.deleteById(id);
    }

    public AlunoTurma buscarPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Matrícula não encontrada: " + id));
    }

    public List<AlunoTurma> listarTodos() {
        return repo.findAll();
    }

    public List<AlunoTurma> listarPorAluno(Long alunoId) {
        return repo.findByAlunoId(alunoId);
    }

    public List<AlunoTurma> listarPorTurma(Long turmaId) {
        return repo.findByTurmaId(turmaId);
    }
}
