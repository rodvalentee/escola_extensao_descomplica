// ProfessorService.java
package com.escolinha.escolinha.service;

import com.escolinha.escolinha.model.Professor;
import com.escolinha.escolinha.repository.ProfessorRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProfessorService {
    private final ProfessorRepository repo;

    public Professor criar(Professor professor) {
        return repo.save(professor);
    }

    public Professor atualizar(Long id, Professor dados) {
        Professor p = buscarPorId(id);
        p.setNome(dados.getNome());
        p.setEmail(dados.getEmail());
        return repo.save(p);
    }

    public void excluir(Long id) {
        repo.deleteById(id);
    }

    public Professor buscarPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Professor não encontrado: " + id));
    }

    public List<Professor> listarTodos() {
        return repo.findAll();
    }

    public List<Professor> buscarPorNome(String nome) {
        return repo.findByNomeContainingIgnoreCase(nome);
    }
}
