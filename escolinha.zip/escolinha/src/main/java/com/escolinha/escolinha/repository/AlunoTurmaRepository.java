// AlunoTurmaRepository.java
package com.escolinha.escolinha.repository;

import com.escolinha.escolinha.model.AlunoTurma;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AlunoTurmaRepository extends JpaRepository<AlunoTurma, Long> {
    List<AlunoTurma> findByTurmaId(Long turmaId);
    List<AlunoTurma> findByAlunoId(Long alunoId);
}
