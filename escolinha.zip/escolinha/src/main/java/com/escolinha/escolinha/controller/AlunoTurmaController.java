// AlunoTurmaController.java
package com.escolinha.escolinha.controller;

import com.escolinha.escolinha.model.AlunoTurma;
import com.escolinha.escolinha.service.AlunoTurmaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/matriculas")
@RequiredArgsConstructor
public class AlunoTurmaController {
    private final AlunoTurmaService service;

    @PostMapping
    public ResponseEntity<AlunoTurma> matricular(@RequestBody AlunoTurma at) {
        return ResponseEntity.ok(service.matricular(at));
    }

    @GetMapping
    public ResponseEntity<List<AlunoTurma>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> desmatricular(@PathVariable Long id) {
        service.desmatricular(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlunoTurma> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }
}
