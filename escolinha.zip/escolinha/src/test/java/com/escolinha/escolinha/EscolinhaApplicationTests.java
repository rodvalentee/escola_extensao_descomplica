package com.escolinha.escolinha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolinhaApplicationTests {

    @Test
    void contextLoads() {
    }

}
