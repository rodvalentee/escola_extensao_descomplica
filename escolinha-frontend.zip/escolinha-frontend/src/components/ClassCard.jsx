// src/components/ClassCard.jsx
import React from 'react';

export default function ClassCard({ turma, onClick }) {
    return (
        <div
            onClick={() => onClick(turma.id)}
            className="bg-white p-4 rounded-lg shadow mb-4 cursor-pointer hover:shadow-md"
        >
            <h2 className="text-xl font-semibold">{turma.nome}</h2>
            <p className="text-gray-600">
                Professor: {turma.professor?.nome ?? '—'}
            </p>
            <p className="text-gray-600">
                {turma.alunosCount ?? turma.matriculas?.length ?? 0} alunos
            </p>
        </div>
    );
}
