// src/components/Sidebar.jsx
import { NavLink } from 'react-router-dom';

export default function Sidebar() {
    return (
        <aside className="w-60 bg-white h-screen border-r p-6">
            <h1 className="text-2xl font-bold mb-8">Escolinha</h1>
            <nav className="flex flex-col space-y-4 text-gray-700">
                <NavLink
                    to="/professores"
                    className={({ isActive }) =>
                        isActive ? 'text-blue-600 font-semibold' : 'hover:text-blue-600'
                    }
                >
                    Professores
                </NavLink>
                <NavLink
                    to="/turmas"
                    className={({ isActive }) =>
                        isActive ? 'text-blue-600 font-semibold' : 'hover:text-blue-600'
                    }
                >
                    Turmas
                </NavLink>
                <NavLink
                    to="/alunos"
                    className={({ isActive }) =>
                        isActive ? 'text-blue-600 font-semibold' : 'hover:text-blue-600'
                    }
                >
                    Alunos
                </NavLink>
            </nav>
        </aside>
    );
}
