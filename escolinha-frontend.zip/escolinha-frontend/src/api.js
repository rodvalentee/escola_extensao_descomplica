// src/api.js
import axios from 'axios';

const api = axios.create({
    baseURL: '/api',            // <- sem host
    headers: { 'Content-Type': 'application/json' },
});

api.defaults.headers.post['Content-Type'] = 'application/json';
// Exemplo de interceptor para pegar erros globais
api.interceptors.response.use(
    res => res,
    err => {
        console.error('API Error:', err.response || err.message);
        return Promise.reject(err);
    }
);

export default api;
