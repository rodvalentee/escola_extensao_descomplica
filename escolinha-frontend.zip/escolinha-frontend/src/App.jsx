// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Professores from './pages/Professores'
import Turmas from './pages/Turmas'
import Alunos from './pages/Alunos'
import TurmaDetail from './pages/TurmaDetail'
import AlunoDetail from './pages/AlunoDetail'
import ProfessorDetail from './pages/ProfessorDetail'
import AlunoForm from './pages/AlunoForm';
import ProfessorForm from './pages/ProfessorForm';
import TurmaForm from './pages/TurmaForm';


export default function App() {
    return (
        <BrowserRouter>
            <div className="flex">
                <Sidebar />
                <main className="flex-1 p-6 bg-gray-50 min-h-screen">
                    <Routes>
                        <Route path="/" element={<Navigate to="/turmas" replace />} />
                        <Route path="/professores" element={<Professores />} />
                        <Route path="/professores/:id" element={<ProfessorDetail />} />
                        <Route path="/turmas" element={<Turmas />} />
                        <Route path="/turmas/novo" element={<TurmaForm />} />
                        <Route path="/turmas/:id" element={<TurmaDetail />} />
                        <Route path="/alunos" element={<Alunos />} />
                        <Route path="/alunos/:id" element={<AlunoDetail />} />

                        <Route path="/alunos" element={<Alunos />} />
                        <Route path="/alunos/novo" element={<AlunoForm />} />
                        <Route path="/alunos/:id" element={<AlunoDetail />} />

                        <Route path="/professores" element={<Professores />} />
                        <Route path="/professores/novo" element={<ProfessorForm />} />
                        <Route path="/professores/:id" element={<ProfessorDetail />} />

                    </Routes>
                </main>
            </div>
        </BrowserRouter>
    )
}
