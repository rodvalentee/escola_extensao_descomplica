// src/pages/ProfessorDetail.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';

export default function ProfessorDetail() {
    const { id } = useParams();
    const [professor, setProfessor] = useState(null);

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get(`/professores/${id}`);
                setProfessor(data);
            } catch (error) {
                console.error('Erro ao buscar detalhes do professor', error);
            }
        })();
    }, [id]);

    if (!professor) return <p>Carregando...</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Professor: {professor.nome}</h1>
            <p className="mb-2">Email: {professor.email}</p>
            <h2 className="text-xl font-semibold mb-2">Turmas</h2>
            {professor.turmas && professor.turmas.length > 0 ? (
                <ul className="list-disc list-inside">
                    {professor.turmas.map((t) => (
                        <li key={t.id}>
                            <Link to={`/turmas/${t.id}`} className="text-blue-600 hover:underline">
                                {t.nome}
                            </Link>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>Este professor não tem turmas cadastradas.</p>
            )}
        </div>
    );
}
