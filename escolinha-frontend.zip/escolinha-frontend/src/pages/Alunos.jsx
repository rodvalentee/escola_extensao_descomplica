// src/pages/Alunos.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';


export default function Alunos() {
    const [alunos, setAlunos] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get('/alunos');
                setAlunos(data);
            } catch (error) {
                console.error('Erro ao buscar alunos', error);
            }
        })();
    }, []);

    const handleClick = (id) => {
        navigate(`/alunos/${id}`);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Alunos</h1>
                <Link
                    to="/alunos/novo"
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    + Novo Aluno
                </Link>
            </div>

            <h1 className="text-2xl font-bold mb-6">Alunos</h1>
            {alunos.map((a) => (
                <div
                    key={a.id}
                    onClick={() => handleClick(a.id)}
                    className="bg-white p-4 rounded-lg shadow mb-4 cursor-pointer hover:shadow-md"
                >
                    <h2 className="text-xl font-semibold">{a.nome}</h2>
                    <p className="text-gray-600">{a.email}</p>
                </div>
            ))}
        </div>
    );
}
