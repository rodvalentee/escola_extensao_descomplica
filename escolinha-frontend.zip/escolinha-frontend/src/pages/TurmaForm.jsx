// src/pages/TurmaForm.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function TurmaForm() {
    const [nome, setNome] = useState('');
    const [professores, setProfessores] = useState([]);
    const [professorId, setProfessorId] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get('/professores');
                setProfessores(data);
            } catch (err) {
                console.error('Erro ao buscar professores', err);
            }
        })();
    }, []);

    const handleSubmit = async (e) => {

        await api.post(
            '/turmas',
            { nome, professor: { id: professorId } },
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        e.preventDefault();
        if (!professorId) {
            setError('Selecione um professor');
            return;
        }
        setLoading(true);
        setError(null);
        try {
            await api.post('/turmas', {
                nome,
                professor: { id: professorId }
            });
            navigate('/turmas');
        } catch (err) {
            setError(err.response?.data?.message || 'Erro ao cadastrar turma');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow">
            <h1 className="text-2xl font-bold mb-4">Cadastrar Turma</h1>
            {error && <p className="text-red-500 mb-4">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="nome" className="block text-sm font-medium text-gray-700">
                        Nome da Turma
                    </label>
                    <input
                        id="nome"
                        type="text"
                        value={nome}
                        onChange={(e) => setNome(e.target.value)}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md p-2"
                    />
                </div>
                <div>
                    <label htmlFor="professor" className="block text-sm font-medium text-gray-700">
                        Professor Responsável
                    </label>
                    <select
                        id="professor"
                        value={professorId}
                        onChange={(e) => setProfessorId(e.target.value)}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md p-2"
                    >
                        <option value="">-- selecione --</option>
                        {professores.map((p) => (
                            <option key={p.id} value={p.id}>
                                {p.nome}
                            </option>
                        ))}
                    </select>
                </div>
                <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                    {loading ? 'Salvando...' : 'Salvar'}
                </button>
            </form>
        </div>
    );
}
