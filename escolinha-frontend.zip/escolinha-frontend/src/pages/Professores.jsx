// src/pages/Professores.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';

export default function Professores() {
    const [professores, setProfessores] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get('/professores');
                setProfessores(data);
            } catch (error) {
                console.error('Erro ao buscar professores', error);
            }
        })();
    }, []);

    const handleClick = (id) => {
        navigate(`/professores/${id}`);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Professores</h1>
                <Link
                    to="/professores/novo"
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                    + Novo Professor
                </Link>
            </div>

            {professores.map((p) => (
                <div
                    key={p.id}
                    onClick={() => handleClick(p.id)}
                    className="bg-white p-4 rounded-lg shadow mb-4 cursor-pointer hover:shadow-md"
                >
                    <h2 className="text-xl font-semibold">{p.nome}</h2>
                    <p className="text-gray-600">{p.email}</p>
                </div>
            ))}
        </div>
    );
}
