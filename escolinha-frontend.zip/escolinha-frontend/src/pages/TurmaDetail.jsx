// src/pages/TurmaDetail.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';

export default function TurmaDetail() {
    const { id } = useParams();
    const [turma, setTurma] = useState(null);

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get(`/turmas/${id}`);
                const { data: alunosTurma } = await api.get(`/turmas/${id}/alunos`);
                const alunos = alunosTurma.map(at => at.aluno);
                setTurma({ ...data, alunos });
            } catch (error) {
                console.error('Erro ao buscar detalhes da turma', error);
            }
        })();
    }, [id]);

    if (!turma) return <p>Carregando...</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Turma: {turma.nome}</h1>
            <p className="mb-4">Professor: {turma.professor.nome}</p>
            <h2 className="text-xl font-semibold mb-2">Alunos</h2>
            <ul className="list-disc list-inside">
                {turma.alunos.map(aluno => (
                    <li key={aluno.id}>
                        <Link to={`/alunos/${aluno.id}`} className="text-blue-600 hover:underline">
                            {aluno.nome}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>

    );
}
