// src/pages/Turmas.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';
import ClassCard from '../components/ClassCard';

export default function Turmas() {
    const [turmas, setTurmas] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get('/turmas');
                setTurmas(data);
            } catch (error) {
                console.error('Erro ao buscar turmas', error);
            }
        })();
    }, []);

    const handleClick = (id) => {
        navigate(`/turmas/${id}`);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Turmas</h1>
                <Link
                    to="/turmas/novo"
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                    + Nova Turma
                </Link>
            </div>
            <div>
                <h1 className="text-2xl font-bold mb-6">Turmas</h1>
                {turmas.map((t) => (
                    <ClassCard
                        key={t.id}
                        turma={t}
                        onClick={handleClick}
                    />
                ))}
            </div>
        </div>

    );
}
