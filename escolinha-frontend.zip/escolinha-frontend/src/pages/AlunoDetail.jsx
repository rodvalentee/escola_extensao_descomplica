// src/pages/AlunoDetail.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';

export default function AlunoDetail() {
    const { id } = useParams();
    const [aluno, setAluno] = useState(null);
    const [turmas, setTurmas] = useState([]);

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get(`/alunos/${id}`);
                setAluno(data);
                const { data: turmasData } = await api.get(`/alunos/${id}/turmas`);
                setTurmas(turmasData.map(at => at.turma));
            } catch (error) {
                console.error('Erro ao buscar detalhes do aluno', error);
            }
        })();
    }, [id]);

    if (!aluno) return <p>Carregando...</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Aluno: {aluno.nome}</h1>
            <p className="mb-2">Email: {aluno.email}</p>
            <h2 className="text-xl font-semibold mb-2">Turmas</h2>
            <ul className="list-disc list-inside">
                {turmas.map((t) => (
                    <li key={t.id}>
                        <Link to={`/turmas/${t.id}`} className="text-blue-600 hover:underline">
                            {t.nome}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}
